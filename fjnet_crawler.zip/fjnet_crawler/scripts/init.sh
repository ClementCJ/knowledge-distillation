  java -Dlog4j.configuration=log4j-init.properties -cp ".:./fjnet_crawler-1.0-SNAPSHOT-jar-with-dependencies.jar" com.antbrains.fjnet_crawler.scheduler.Init  "jnp://ai-dev:1099" ai-dev:3333 fjnet
