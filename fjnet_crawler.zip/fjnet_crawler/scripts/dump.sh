java  -Dlog4j.configuration=log4j-dump.properties -cp ".:./fjnet_crawler-1.0-SNAPSHOT-jar-with-dependencies.jar" com.antbrains.fjnet_crawler.dumper.DumpHtml fjent /tmp/fjnet_html.txt 
