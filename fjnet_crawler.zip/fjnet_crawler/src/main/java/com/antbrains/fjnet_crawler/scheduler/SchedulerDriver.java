package com.antbrains.fjnet_crawler.scheduler;

import com.antbrains.mysqltool.PoolManager;
import com.antbrains.sc.scheduler.FileUnfinishedScheduler;

public class SchedulerDriver {

	public static void main(String[] args) throws Exception {
		FileUnfinishedScheduler.main(args);
	}

}
