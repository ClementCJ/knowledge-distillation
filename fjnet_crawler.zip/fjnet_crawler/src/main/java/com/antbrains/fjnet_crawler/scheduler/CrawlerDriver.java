package com.antbrains.fjnet_crawler.scheduler;

import com.antbrains.sc.worker.BasicCrawlerWithFileFrontier;

public class CrawlerDriver {

	public static void main(String[] args) throws Exception {
		BasicCrawlerWithFileFrontier.main(args);
	}

}
